function setup() {
  createCanvas(800, 300);
}

function draw() {
  background(207, 226, 243);
 
  //cloud 1
  strokeWeight(0);
  ellipse(150, 100, 75, 75);
  
  //circle 2
  strokeWeight(0);
  ellipse(110, 120, 75, 75);
  
  //circle 3
  strokeWeight(0);
  ellipse(180, 130, 80, 60);
  
  //circle 4
  strokeWeight(0);
  ellipse(185, 140, 155, 40);
  
  //circle 5
  strokeWeight(0);
  ellipse(130, 135, 140, 50);
  
  //cloud 2
  strokeWeight(0);
  ellipse(400, 200, 75, 75);
  
  //circle 2
  strokeWeight(0);
  ellipse(360,220, 75, 75);
  
  //circle 3
  strokeWeight(0);
  ellipse(430, 230, 80, 60);
  
  //circle 4
  strokeWeight(0);
  ellipse(435, 240, 155, 40);
  
  //circle 5
  strokeWeight(0);
  ellipse(380, 235, 140, 50);
  
  
  
  
}